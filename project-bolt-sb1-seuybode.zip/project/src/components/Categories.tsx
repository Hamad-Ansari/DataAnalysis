import React from 'react';
import { MessageSquare, Image, Code, Music, Brain, Video } from 'lucide-react';

const categories = [
  {
    name: 'Language AI',
    icon: <MessageSquare className="h-8 w-8 text-purple-600" />,
    count: 15
  },
  {
    name: 'Image Generation',
    icon: <Image className="h-8 w-8 text-purple-600" />,
    count: 12
  },
  {
    name: 'Development',
    icon: <Code className="h-8 w-8 text-purple-600" />,
    count: 8
  },
  {
    name: 'Audio Generation',
    icon: <Music className="h-8 w-8 text-purple-600" />,
    count: 6
  },
  {
    name: 'Video Generation',
    icon: <Video className="h-8 w-8 text-purple-600" />,
    count: 4
  },
  {
    name: 'Research & Analysis',
    icon: <Brain className="h-8 w-8 text-purple-600" />,
    count: 10
  }
];

export default function Categories() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {categories.map((category) => (
        <div
          key={category.name}
          className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
        >
          <div className="flex items-center space-x-4">
            <div className="p-2 bg-purple-100 rounded-lg">
              {category.icon}
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">{category.name}</h3>
              <p className="text-sm text-gray-600">{category.count} tools</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}