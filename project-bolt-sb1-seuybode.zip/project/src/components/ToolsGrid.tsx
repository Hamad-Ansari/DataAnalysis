import React from 'react';
import ToolCard from './ToolCard';
import { Brain, Image, MessageSquare, Code, PenTool, Music } from 'lucide-react';

const tools = [
  {
    title: 'ChatGPT',
    description: 'Advanced language model for natural conversations and content generation',
    category: 'Language AI',
    icon: <MessageSquare className="h-6 w-6 text-purple-600" />,
    url: 'https://chat.openai.com'
  },
  {
    title: 'DALL-E',
    description: 'Create stunning artwork and images from text descriptions',
    category: 'Image Generation',
    icon: <Image className="h-6 w-6 text-purple-600" />,
    url: 'https://openai.com/dall-e-2'
  },
  {
    title: 'GitHub Copilot',
    description: 'AI-powered code completion and suggestion tool',
    category: 'Development',
    icon: <Code className="h-6 w-6 text-purple-600" />,
    url: 'https://github.com/features/copilot'
  },
  {
    title: 'Midjourney',
    description: 'Create beautiful artwork using AI-powered image generation',
    category: 'Image Generation',
    icon: <PenTool className="h-6 w-6 text-purple-600" />,
    url: 'https://www.midjourney.com'
  },
  {
    title: 'Claude',
    description: 'Advanced AI assistant for analysis and content creation',
    category: 'Language AI',
    icon: <Brain className="h-6 w-6 text-purple-600" />,
    url: 'https://anthropic.com/claude'
  },
  {
    title: 'Mubert',
    description: 'AI-powered music generation and composition',
    category: 'Audio Generation',
    icon: <Music className="h-6 w-6 text-purple-600" />,
    url: 'https://mubert.com'
  }
];

export default function ToolsGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {tools.map((tool) => (
        <ToolCard key={tool.title} {...tool} />
      ))}
    </div>
  );
}