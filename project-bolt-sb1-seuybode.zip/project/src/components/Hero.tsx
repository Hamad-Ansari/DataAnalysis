import React from 'react';
import { Sparkles } from 'lucide-react';

export default function Hero() {
  return (
    <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center">
          <Sparkles className="h-12 w-12 mx-auto mb-6" />
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Discover the Power of AI
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Explore our curated collection of cutting-edge AI tools to enhance your productivity and creativity
          </p>
          <a
            href="#tools"
            className="inline-block bg-white text-purple-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors"
          >
            Explore Tools
          </a>
        </div>
      </div>
    </div>
  );
}