import React from 'react';
import { ExternalLink } from 'lucide-react';

interface ToolCardProps {
  title: string;
  description: string;
  category: string;
  icon: React.ReactNode;
  url: string;
}

export default function ToolCard({ title, description, category, icon, url }: ToolCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center mb-4">
        <div className="p-2 bg-purple-100 rounded-lg">
          {icon}
        </div>
        <div className="ml-4">
          <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
          <span className="text-sm text-purple-600">{category}</span>
        </div>
      </div>
      <p className="text-gray-600 mb-4">{description}</p>
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center text-purple-600 hover:text-purple-700"
      >
        Learn More
        <ExternalLink className="ml-1 h-4 w-4" />
      </a>
    </div>
  );
}