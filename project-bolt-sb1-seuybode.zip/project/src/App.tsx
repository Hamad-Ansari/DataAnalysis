import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ToolsGrid from './components/ToolsGrid';
import Categories from './components/Categories';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <Hero />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <section id="tools" className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Featured AI Tools</h2>
          <ToolsGrid />
        </section>

        <section id="categories" className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Browse by Category</h2>
          <Categories />
        </section>

        <section id="about" className="mb-16">
          <div className="bg-white rounded-lg shadow-sm p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">About AI Tools Hub</h2>
            <p className="text-gray-600 mb-4">
              AI Tools Hub is your comprehensive resource for discovering and exploring the latest artificial intelligence tools. 
              We curate the best AI-powered solutions across various categories to help you enhance your productivity, creativity, 
              and workflow.
            </p>
            <p className="text-gray-600">
              Whether you're a developer, designer, content creator, or business professional, 
              our collection of AI tools will help you stay ahead in the rapidly evolving world of technology.
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-gray-400">
            © {new Date().getFullYear()} AI Tools Hub. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;